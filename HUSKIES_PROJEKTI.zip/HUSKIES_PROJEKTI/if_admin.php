<?php if(!isset($_SESSION)) { session_start(); }

if (isset($_SESSION["usr"]) && isset($_SESSION["id"]) && $_SESSION["loggedin"]==TRUE) {
		$_SESSION["TIMENOW"] = time();
		
	if ($_SESSION["TIMENOW"] > $_SESSION["TIMEOUT"]) {
		unset($_SESSION["id"],$_SESSION["usr"],$_SESSION["loggedin"]);
		unset($_SESSION["TIMENOW"],$_SESSION["TIMEOUT"]);
		$message["users"] = "TIMEOUT";
		$msg = json_encode($message);
		print $msg;
		session_destroy();
	} else {
		$_SESSION["TIMENOW"] = time();
		$message["users"] = "<a class='nav-link' href='./users.php'>Users</a>";
		$message["log_out"] = "<a class='nav-link' href='./exit_session.php'>Log out</a>";
		$msg = json_encode($message);
		print $msg;	
	} 
}
?>
