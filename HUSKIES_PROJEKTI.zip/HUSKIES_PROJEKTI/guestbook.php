<?php include './includes/header.php'; ?>
<?php include './includes/nav.php'; ?>
<?php include './includes/func.php'; ?>

<?php


$xml=simplexml_load_file("./config.xml");
$connection = connect($xml->host,$xml->user,$xml->password ,$xml->database);
#mysqli_set_charset($link,"utf8");


 

?>


<div class="guestbook-husky-container">
  <div class="husky-heading">
    <h1>Guestbook</h1>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-lg btn-outline-light py-4" data-toggle="modal" data-target="#guestbookMessage">
      Write to the Guestbook!
    </button>
  </div>

  <hr />
  <!--Tämä osio laitetaan looppaamaan tietokanta-->


  <?php
  $query = "SELECT * FROM husky_user3 ";
$query .= "ORDER BY id_user DESC;";
//printGuestBookPosts
if ($result = mysqli_query($connection, $query)){
 
	 print_guestbook($connection,$result);
	 
 
	mysqli_free_result($result);
}

  ?>

  <!--Tästä alkaa uusi viesti-->
  <?php
  if (isset($_POST['create_message'])) {
    
    $name = test_input ($_POST['firstname']);
    $surname = test_input ($_POST['lastname']);
    $mail = test_input ($_POST['email']);
    $message = test_input($_POST['message']);
    
	  if(insert_into_guestbook($connection, $name, $surname, $mail, $message)){
		  //print("<BR>INSERTED<BR>");
	  }
	  else {
		//print("<BR>NOT INSERTED<BR>");
	}
		
	
		
  }
  ?>

</div>
<!--husky container loppuu-->
<!-- Modal -->
<div class="modal fade" id="guestbookMessage" tabindex="-1" role="dialog" aria-labelledby="#guestbookMessage" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content guestbook-husky-modal">
      <div class="modal-header">
        <h5 class="modal-title" id="guestbookMessage">
          Create a new message!
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="POST">
        <div class="modal-body">
          <div class="row">
            <div class="col-6 form-group">
              <label for="firstname">Firstname:</label>
              <input class="form-control" type="text" name="firstname" placeholder="Firstname" required />
            </div>
            <div class="col-6 form-group">
              <label for="lastname">Lastname:</label>
              <input class="form-control" type="text" name="lastname" placeholder="Lastname" required />
            </div>
            <div class="col-12 form-group">
              <label for="email">Email</label>
              <input class="form-control" type="email" name="email" placeholder="email@here" />
            </div>
            <div class="col-12 form-group">
              <label for="message">Message or Comment:</label>
              <textarea class="form-control" rows="5" name="message" minlength="5" required></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">
            Close
          </button>
          <button type="submit" class="btn btn-success" name="prewiew">
            Prewiew
          </button>
          <button type="submit" class="btn btn-primary" name="create_message">
            Send
          </button>
        </div>
      </form>
    </div>
  </div>
</div>



<?php include './includes/footer.php'; ?>