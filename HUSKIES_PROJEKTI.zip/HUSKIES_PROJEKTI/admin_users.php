<?php if(!isset($_SESSION)) { session_start(); }

if (isset($_SESSION["usr"]) && isset($_SESSION["id"]) && isset($_SESSION["loggedin"])) {
  print "<a class='nav-link' href='./users.php'>Users</a>";
}?>
