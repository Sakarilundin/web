<?php if (!isset($_SESSION)) { session_start(); }

if (isset($_SESSION["usr"]) && isset($_SESSION["id"]) && $_SESSION["loggedin"]==TRUE) {
  header("Location:admin.php");
} else {
  header("Location:session_expired.php");
}
?>
