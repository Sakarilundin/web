function yhdista() {

$.ajax({
  url:"login_admin.php",
  async:true,
  dataType:"text",
  type:"POST",
  contentType:'application/x-www-form-urlencoded',
  data:{user:$("#id").val(),pass:$("#passwd").val()},
  success:function(data) {
    var vastaus=data.trim();
    if (vastaus==="1") {
      var logged_in="admin_view.php";
      window.location.href=logged_in;
    } else if(vastaus==="2") {
      console.log("Virhe tietojen lisäyksessä.");
    } else if(vastaus==="3") {
      console.log("Virheellinen kysely.");
    } else if(vastaus==="4") {
      console.log("Virhe tietokantaan yhdistettäessä.");
    } else {
      $("#viesti").html(vastaus);
    }

  }
});

  setTimeout(function() { document.getElementById("viesti").innerHTML="";
  var tiedot = document.getElementsByClassName("info");
  for (var i=0; i < tiedot.length; i++) { tiedot[i].value="";}}, 3000);
}