function if_admin() {

$.ajax({
    url:"if_admin.php",
    async:true,
    dataType:"text",
    type:"POST",
    contentType:'application/x-www-form-urlencoded',
    success:function(data) {
      var vastaus = JSON.parse(data.trim());
	  if (vastaus.users==="TIMEOUT") {
	    var takaisin = "index.php";
		window.location.href=takaisin;
	  } else {
		$("#admin_users").html(vastaus.users);
		$("#admin_exit").html(vastaus.log_out);
	  }
    }
  });	
}

function laheta() {

  $.ajax({
    url:"add_info.php",
    async:true,
    dataType:"text",
    type:"POST",
    contentType:'application/x-www-form-urlencoded',
    data:{etunimi:$("#etu").val(),sukunimi:$("#suku").val(),posti:$("#s_posti").val(),
    viesti:$("#palaute").val()},
    success:function(data) {
      var vastaus=data.trim();
      if (vastaus==="1") {
          console.log("Yhteystietojen lisäyksessä virhe.");
      } else if (vastaus==="2") {
          console.log("Virheellinen tietokantakysely.");
      } else if (vastaus==="3") {
          console.log("Virhe palvelimeen yhdistettäessä.");
      } else {
        $("#viesti").html(vastaus);
      }
    }
  });

  setTimeout(function() { document.getElementById("viesti").innerHTML="";
  var tiedot = document.getElementsByClassName("info");
  for (var i=0; i < tiedot.length; i++) { tiedot[i].value="";}}, 3000);
}