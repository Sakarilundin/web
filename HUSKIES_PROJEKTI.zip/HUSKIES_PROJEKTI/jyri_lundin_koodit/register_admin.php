<?php if(!isset($_SESSION)) { session_start(); }

function muodosta_yhteys() {

  $set=parse_ini_file("huskies.ini");
  $connect=mysqli_connect($set["server"],$set["user"],
           $set["passwd"],$set["db"]);

  if ($connect!=false) {
    return $connect;
  } else {
    return false;
  }
}

function valmistele_lisays($conn) {

  $adduser="INSERT INTO husky_users (user,pass,email,admin) VALUES (?,?,?,?)";
  $query=mysqli_prepare($conn,$adduser);

  if ($query!=false) {
    return $query;
  } else {
    return false;
  }
}

function lisaa_tiedot($query,$conn,$user,$pass,$mail) {

  mysqli_stmt_bind_param($query,'sssi',$user,$pass,$mail,$admin);
  
  define("admin_true",'1');

  $user=mysqli_real_escape_string($conn,$user);
  $pass=mysqli_real_escape_string($conn,md5($pass));
  $mail=mysqli_real_escape_string($conn,$mail);
  $admin=mysqli_real_escape_string($conn,admin_true);

  if (mysqli_stmt_execute($query)==true) {
    mysqli_stmt_close($query);
    return true;
  } else {
    mysqli_stmt_close($query);
    return false;
  }
}

$yhteys = muodosta_yhteys();
if ($yhteys!=false) {
  $kysely = valmistele_lisays($yhteys);
  if ($kysely!=false) {
    $lisays = lisaa_tiedot($kysely,$yhteys,$_POST["user"],
              $_POST["pass"],$_POST["email"]);
    if ($lisays==true) {
      $_SESSION["user"] = $_POST["user"];
      $_SESSION["mail"] = $_POST["email"];
      print "1";
    } else {
      print "2";
    }
  } else {
    print "3";
  }
} else {
  print "4";
}

?>
