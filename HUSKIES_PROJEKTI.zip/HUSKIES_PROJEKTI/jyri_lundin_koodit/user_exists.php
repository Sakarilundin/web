<?php

function kayttaja_tyhja($usr) {
  if (empty($usr)) {
    return true;
  } else {
    return false;
  }
}

function tarkista_salasana($passwd,$verify) {
  if (!empty($passwd) && !empty($verify)) {
    if ($verify===$passwd) {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}


function salasana_vaatimukset($passwd,$verify,$criteria) {
  if (strlen($passwd) >= $criteria["length"] &&
  strlen($verify) >= $criteria["length"]) {
    return true;
  } else {
    return false;
  }
}


function tarkista_sahkoposti($mail) {
  if (filter_var($mail,FILTER_VALIDATE_EMAIL)) {
    return true;
  } else {
    return false;
  }
}

function yhteys() {
  $server=parse_ini_file("huskies.ini");
  $connect=mysqli_connect($server["server"],$server["user"],
          $server["passwd"],$server["db"]);

  if ($connect!=false) {
    return $connect;
  } else {
    return false;
  }
}

function valmistele_tiedot($conn) {

  $query="SELECT id,user FROM husky_users  WHERE user=?";
  $prep_info=mysqli_prepare($conn,$query);

  if($prep_info!=false) {
    return $prep_info;
  } else {
    return false;
  }
}

function etsi_kayttaja($prepd,$conn,$usr) {

  mysqli_stmt_bind_param($prepd,'s',$user);
  $user=mysqli_real_escape_string($conn,$usr);

  if (mysqli_stmt_execute($prepd)==true) {
    return $prepd;
  } else {
    return false;
  }
}

function hae_tulokset($info) {

  mysqli_stmt_bind_result($info,$id,$user);
  while(mysqli_stmt_fetch($info)) {
    $login["id"]=$id;
    $login["usr"]=$user;
  }
  if(!empty($login["id"]) && !empty($login["usr"])) {
    return $login;
  } else {
    return false;
  }
}

?>
