<?php if(!isset($_SESSION)) { session_start(); }

include("login_admin_functions.php");

if (kayttaja_tyhja($_POST["user"])==true) {
  print "<p>Missing username. Input username.</p>";
} else if (salasana_tyhja($_POST["pass"])==true) {
  print "<p>Missing password. Input password.</p>";
} else {

  $yhteys=yhteys();

  if ($yhteys!=false) {

    $valmisteltu=valmistele_tiedot($yhteys);

    if ($valmisteltu!=false) {

      $tiedot=etsi_kayttaja($valmisteltu,$yhteys,$_POST["user"],$_POST["pass"]);

      if ($tiedot!=false) {
        $haku=hae_tulokset($tiedot);
        if ($haku!=false) {
          $_SESSION["usr"]=$haku["usr"];
          $_SESSION["id"]=$haku["id"];
          $_SESSION["loggedin"]=TRUE;
          $_SESSION["TIMENOW"] = time();
          $_SESSION["TIMEOUT"] = $_SESSION["TIMENOW"] + (5*60);
          print "1";
        } else {
          print "<p>User or password was not found.
          Check username and password.</p>";
          mysqli_close($yhteys);
        }
      } else {
        mysqli_close($yhteys);
        print "2";
      }
    } else {
      mysqli_close($yhteys);
      print "3";
    }
  } else {
    mysqli_close($yhteys);
    print "4";
  }
}
?>
