<?php if (!isset($_SESSION)) { session_start(); }

include("funktiot.php");

if (etunimi_tyhja($_POST["etunimi"])==false) {
  print "<p>First name empty or contains non-alphabet special characters. Please provide your name again.</p>";
} else if (sahkoposti_tyhja($_POST["posti"])==false) {
  print "<p>Email empty or malformed. Please provide your email.</p>";
} else if (viesti_tyhja($_POST["viesti"])==false) {
  print "<p>Message empty.Write your message.</p>";
} else {

 if (sukunimi($_POST["sukunimi"])==false) {
    $_POST["sukunimi"]="";
 }

 $yhteys=yhteys();

 if ($yhteys!=false) {
      $valmisteltu=valmistele_tiedot($yhteys);
    if ($valmisteltu!=false) {
        $tiedot=lisaa_tiedot($valmisteltu,$yhteys,$_POST["etunimi"],
        $_POST["sukunimi"],$_POST["posti"],$_POST["viesti"]);
      if ($tiedot==true) {
        print "<p>Message sent successfully!</p>";
        mysqli_close($yhteys);
      } else {
        mysqli_close($yhteys);
        print "2";
      }
    } else {
      mysqli_close($yhteys);
      print "3";
    }
 } else {
    mysqli_close($yhteys);
    print "4";
   }
}
?>
