<?php if (!isset($_SESSION)) { session_start(); }

unset($_SESSION["usr"],$_SESSION["id"],$_SESSION["loggedin"]);
unset($_SESSION["TIMENOW"],$_SESSION["TIMEOUT"]);
session_destroy();
header("Location:index.php");
?>
