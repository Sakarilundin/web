<?php

	

 
function insert_into_guestbook($conn, $name, $surname, $mail, $message){

	$stmt = $conn->prepare("INSERT INTO husky_user3 (name, surname, mail, message) VALUES (?, ?, ?, ?)");
	$stmt->bind_param("ssss", $name, $surname, $mail, $message);


	if ($stmt->execute()) {
 
		return true;
	} else {
 
		return false;
	}
		
}



function print_guestbook($conn, $result){
 
	  while ($row = mysqli_fetch_assoc($result)) {
		echo "<div class='row justify-content-center'>";
		echo "<div class='col-md-8'>";
		echo "<div class='card guestbook-message'>";
		echo "<div class='card-Header pl-3 pt-2 guestbook-husky-card-header'>";
		echo "<h3>" . $row['name'] . " " . $row['surname'] . " <span class='h6'>" . $row['reg_date_TIMESTAMP'] . "</span></h3>";
		echo "<p>" . $row['mail'] . "</p>";
		echo "</div>";
		echo "<div class='card-body'>";
		echo " <p>" . $row['message'] . "</p>";
		echo "</div></div><hr /></div></div>";
	  }
}


function update_guestbook_message($conn, $id, $message){
 
	
	$sql= "UPDATE husky_user3 SET message =? WHERE id_user =?";
	$stmt = $conn->prepare($sql);
	$stmt->bind_param("si", $message, $id);


	if ($stmt->execute()) {
 
		return true;
	} else {
 
		return false;
	}
	 
}
 


 
	function disconnect($link)
{
 
		mysqli_close($link);
 
}
        
	function test_input($data) {
		$data = trim($data);     		//The trim() function removes whitespace and other predefined characters from both sides of a string.
		$data = stripslashes($data);          //Returns a string with backslashes stripped off
		$data = htmlspecialchars($data);      //protects against XSS
		return $data;
}
		
 function row_counter ($table_name,$link, $column){
	
		$total_pages_sql = "SELECT MAX($column) FROM $table_name";
		$result = mysqli_query($link,$total_pages_sql);
		$total_rows = mysqli_fetch_array($result)[0];
		return $total_rows;
}
 
 
 function mysqli_field_name($result, $field_offset)
{
    $properties = mysqli_fetch_field_direct($result, $field_offset);
    return is_object($properties) ? $properties->name : null;
}

function connect($host,$user,$password,$db){
  $link=mysqli_connect($host,$user,$password,$db);
   $link = new mysqli('p:'.$host, $user, $password, $db);  	
    //error case
	if (!$link) {
		echo "Error: Unable to connect to MySQL." . PHP_EOL;
		echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
		echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
		exit;
		echo "mysql connection is okay";
}	
	
	 return ($link);
};






function printGuestBookPosts($result){
	
	while ($row = mysqli_fetch_assoc($result)) {

            echo "<div class='row justify-content-center'>";
            echo "<div class='col-md-8'>";
            echo "<div class='card guestbook-message'>";
            echo "<a class='admin-link' data-toggle='collapse' href='#guestbook" . $row['id_user'] . "' role='button' aria-expanded='false' aria-controls='guestbook'>";
            echo "<div class='card-Header pl-3 pt-2 guestbook-husky-card-header'>";
            echo "<h5>" . $row['name'] . " " . $row['surname'] . " <span class='h5'>| " . $row['mail'] . " |</span> ";
            echo "<span class='h6'>" . $row['reg_date_TIMESTAMP'] . "</span></h5></a>";
            echo "</div><div class='collapse' id='guestbook" . $row['id_user'] . "'>";
            echo "<div class='card-body'>";
            echo "<p>" . $row['message'] . "</p>";
            echo "<form method='GET'><button class='btn btn-danger mr-3' type='submit' value='". $row['id_user'].  "' name='deleteGuestbookMessage'>DELETE</button>";
            echo "<button class='btn btn-warning' type='submit' value='". $row['id_user'].  "' name='editGuestbookMessage'>EDIT</button></form>";
          
			echo " </div></div></div></div></div>";
        }
          
    
}



function print_user_admin($result){
	
	
	
	
	while ($row = mysqli_fetch_assoc($result)) {
			print ("kk");
            echo "<div class='row justify-content-center'>";
            echo "<div class='col-md-8'>";
            echo "<div class='card guestbook-message'>";
            echo "<a class='admin-link' data-toggle='collapse' href='#guestbook" . $row['id_user'] . "' role='button' aria-expanded='false' aria-controls='guestbook'>";
            echo "<div class='card-Header pl-3 pt-2 guestbook-husky-card-header'>";
            echo "<h5>" . $row['name'] . " " . $row['surname'] . " <span class='h5'>| " . $row['mail'] . " |</span> ";
            echo "<span class='h6'>" . $row['reg_date_TIMESTAMP'] . "</span></h5></a>";
            echo "</div><div class='collapse' id='guestbook" . $row['id_user'] . "'>";
            echo "<div class='card-body'>";
            echo "<p>" . $row['message'] . "</p>";
            echo "<form method='GET'><button class='btn btn-danger mr-3' type='submit' value='". $row['id_user'].  "' name='deleteGuestbookMessage'>DELETE</button>";
            echo "<button class='btn btn-warning' type='submit' value='". $row['id_user'].  "' name='editGuestbookMessage'>EDIT</button></form>";
          
			echo " </div></div></div></div></div>";
        }
          
    
}



function deleteGuestbookMessage($connection, $id){
	 $sql="delete from husky_user3 where `id_user`=?";
	  
	 if ($stmt = mysqli_prepare ($connection, $sql)){
		mysqli_stmt_bind_param($stmt, 'i', $id);
		if (mysqli_stmt_execute($stmt)) {
		  print("<center>Deleted succesfully</center>");
			//header("Location:print_guestbook.php");
			
		} 
		else {
			print("<center>Not deleted succesfully</center>");
			//print "Virhe: "  . mysqli_error($connection);
		}
   
	 }
	 	 
	 
 }



 

function deletePostMessage($connection, $id){
	 $sql="delete from husky_test where `tunnus`=?";
	  
	 if ($stmt = mysqli_prepare ($connection, $sql)){
		mysqli_stmt_bind_param($stmt, 'i', $id);
		if (mysqli_stmt_execute($stmt)) {
			print("<center>deleted succesfully</center>");
			//header("Location:print_guestbook.php");

		} 
		else {
			
				print("<center>not deleted</center>");
			//print "Virhe: "  . mysqli_error($connection);
		}
   
	 }
	 
	 
 }

 

	 
function delete_husky_users($connection, $id){
	
	
	 $sql="delete from husky_users where `id`=?";
	  
	 if ($stmt = mysqli_prepare ($connection, $sql)){
		mysqli_stmt_bind_param($stmt, 'i', $id);
		if (mysqli_stmt_execute($stmt)) {
			print("<center>not deleted</center>");
			print("<center>deleted succesfully</center>");

		} 
		else {
			print("<center>not deleted</center>");
		}
   
	 }
	 	 
	 
 }

function delete_husky_test($connection, $id){
	 $sql="delete from husky_test where `tunnus`=?";
	 
	 if ($stmt = mysqli_prepare ($connection, $sql)){
		mysqli_stmt_bind_param($stmt, 'i', $id);
		if (mysqli_stmt_execute($stmt)) {
	
			print("<center>deleted succesfully</center>");
			//header("Location:print_guestbook.php");

		} 
		else {
			print("<center>deleted succesfully</center>");
		}
   
	 }
	 	 
	 
 }





function print_users($result){
	
	while ($row = mysqli_fetch_assoc($result)) {

            echo "<div class='row justify-content-center'>";
            echo "<div class='col-md-8'>";
            echo "<div class='card guestbook-message'>";
            #echo "<a class='admin-link' data-toggle='collapse' " . $row['id_user'] . "' role='button' aria-expanded='false' aria-controls='guestbook'>";
            echo "<div class='card-Header pl-3 pt-2 guestbook-husky-card-header'>";
            echo "<h5>" . $row['id'] . "| " .
				 $row['user'] . " <span class='h5'>";
				 //$row['name'] . " |</span> ";
			//echo $row['surname'] . " |</span> ";
			echo $row['joined'] . " |</span> ";
			echo $row['admin'] . " |</span> ";
			 
			//laita action tanne
			#print("delete husky user");
 
			echo "<form method='GET'><button class='btn btn-danger mr-3' type='submit' value='". $row['id'].  "' name='delete_husky_user'>DELETE</button></form>";
			           // echo "<button class='btn btn-warning' type='submit' //value='". $row['id'].  "' //name='edit_husky_user'>EDIT</button></form>"; 
 
          
			
			
            //echo "<span class='h6'>" . $row['reg_date_TIMESTAMP'] . "</span></h5></a>";
            echo "</div><div class='collapse' id='guestbook" . $row['id'] . "'>";
            echo "<div class='card-body'>";
            //echo "<p>" . $row['message'] . "</p>";
           // echo "<form method='GET'><button class='btn btn-danger mr-3' type='submit' value='". $row['id_user'].  "' name='deleteGuestbookMessage'>DELETE</button>";
           
		    echo " </div></div></div></div></div>";
			
			 
        }
          
    
}

function print_edit_guestbook($result){
 
	while ($row = mysqli_fetch_assoc($result)) {
			echo "<div class='row justify-content-center'>";
			echo "<div class='col-md-8'>";
			echo "<div class='card guestbook-message'>";     
			echo "<div class='card-Header pl-3 pt-2 guestbook-husky-card-header'>";
			echo "<h5>" . $row['name'] . " " . $row['surname'] . " <span class='h5'>| " . $row['mail'] . " |</span> ";
			echo "<span class='h6'>" . $row['reg_date_TIMESTAMP'] . "</span></h5>";
			echo "</div><div>";
			echo "<div class='card-body'>";
			echo "<form'>";
			
			print "<p id='tulos'>";
			echo "<textarea class='form-control' rows='5'  id='newGuestbookMessage' name='newGuestbookMessage'>" . $row['message'] . "</textarea>";  
			//taalla mennaan
			print "<input type=hidden id='msg_id' name='msg_id' " .
			 "  value= " . $row['id_user']  . 
			" </textarea>";
		


			print ("<button name='laheta' id='laheta' class='btn btn-success m-1 form-control' type='submit' value='". $row['id_user'].  "' name=' laheta'>UPDATE</button>");


			
			print "</p>";
			echo " </div></div></div></div></div>";
			
	}
	

}
function contactPosts($result){
	
	 while ($row = mysqli_fetch_assoc($result)) {

            echo "<div class='row justify-content-center'>";
            echo "<div class='col-md-8'>";
            echo "<div class='card guestbook-message'>";
            echo "<a class='admin-link' data-toggle='collapse' href='#guestbook" . $row['tunnus'] . "' role='button' aria-expanded='false' aria-controls='guestbook'>";
            echo "<div class='card-Header pl-3 pt-2 guestbook-husky-card-header'>";
            echo "<h5>" . $row['etunimi'] . " " . $row['sukunimi'] . " <span class='h5'>| " . $row['sahkoposti'] . " |</span> ";
            echo "<span class='h6'>" . $row['reg_date_TIMESTAMP'] . "</span></h5></a>";
            echo "</div><div class='collapse' id='guestbook" . $row['tunnus'] . "'>";
            echo "<div class='card-body'>";
            echo "<p>" . $row['viesti'] . "</p>";
          
			
			
			echo "<form method='POST'><button class='btn btn-danger mr-3' type='submit' value='". $row['tunnus'].  "' name='deletePostMessage'>DELETE</button>";
            echo " </div></div></div></div></div>";
        }
          
    
}



 

 

?> 

  

