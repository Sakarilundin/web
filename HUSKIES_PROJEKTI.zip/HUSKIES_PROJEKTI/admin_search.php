<?php if(!isset($_SESSION)) { session_start(); } 

if (isset($_SESSION["usr"]) && isset($_SESSION["id"]) && $_SESSION["loggedin"]==TRUE) {
  header("Location:admin.php");
} else {

  include("admin_search_functions.php");

  $connection=conn();

  if ($connection!=false) {
    $prepared = prepare_query($connection);
    if ($prepared!=false) {
      $admin_search = search_admin($prepared,$connection);
      if ($admin_search!=false) {
        $result = fetch_admin_result($admin_search);
        if ($result!=false) {
          header("Location:admin_login.html");
        } else {
          header("Location:admin_register.html");
        }
      } else {
        print "Mysqli search error";
      }
    } else {
      print "Invalid query.";
    }
  } else {
    print "Connection error.";
  }
}
?>
