<!DOCTYPE html>
<html lang="fi">
<head>
  <meta charset="utf-8"><title>Admin registration complete</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<style>
  body {background:url(./images/husky.jpg) no-repeat center center fixed; background-size:cover;}
  div#ilmoitus {margin-left:auto; margin-right:auto; text-align:center;}
  div#ilmoitus h1,h2 {color:#ffffff;}
  div#ilmoitus a  {color:#ffffff;}
</style>

<body>
  <div id="ilmoitus">
    <h1>Admin created successfully!</h1>
    <?php print "<h2>Admin ".$_SESSION["user"]." and email ".$_SESSION["mail"]." registered successfully.</h2>";?>
    <a href="admin_login.html">Admin login</a>
  </div>

</body>
</html>
