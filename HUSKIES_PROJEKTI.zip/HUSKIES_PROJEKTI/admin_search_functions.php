<?php

function conn() {
  $server=parse_ini_file("huskies.ini");
  $connect=mysqli_connect($server["server"],$server["user"],
          $server["passwd"],$server["db"]);

  if ($connect!=false) {
    return $connect;
  } else {
    return false;
  }
}

function prepare_query($conn) {
  $query="SELECT id,user FROM husky_users  WHERE admin=?";
  $prep_info=mysqli_prepare($conn,$query);

  if($prep_info!=false) {
    return $prep_info;
  } else {
    return false;
  }
}

function search_admin($prepd,$conn) {
  mysqli_stmt_bind_param($prepd,'i',$admin);
  
  define("admin_true",'1');
  $admin=mysqli_real_escape_string($conn,admin_true);

  if (mysqli_stmt_execute($prepd)==true) {
    return $prepd;
  } else {
    return false;
  }
}

function fetch_admin_result($info) {
  mysqli_stmt_bind_result($info,$id,$user);
  while(mysqli_stmt_fetch($info)) {
    $login["id"]=$id;
    $login["usr"]=$user;
  }
  if(!empty($login["id"]) && !empty($login["usr"])) {
    return $login;
  } else {
    return false;
  }
}


?>
