<?php include './includes/header.php'; ?>

<?php include './includes/nav.php'; ?>



<div class="husky-container">
  <div class="husky-heading">
    <h1>Program - Prices - Opening Hours</h1>
    <div class="info-husky-buttons">
      <a href="#safari" role="button" class="btn btn-sm btn-outline-light m-2">Safari</a>
      <a href="#sledding" role="button" class="btn btn-sm btn-outline-light m-2">Sledding</a>
      <a href="#hike" role="button" class="btn btn-sm btn-outline-light m-2">Hike</a>
      <a href="#play" role="button" class="btn btn-sm btn-outline-light m-2">Play</a>
      <a href="#walk" role="button" class="btn btn-sm btn-outline-light m-2">Walk</a>
      <a href="#other" role="button" class="btn btn-sm btn-outline-light m-2">Other</a>
      <div class="fixed-bottom text-right">
        <a href="#top" role="button" class="btn btn-sm btn-outline-light m-2"><svg class="bi bi-arrow-up-long" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M8 5.5a.5.5 0 01.5.5v5a.5.5 0 01-1 0V6a.5.5 0 01.5-.5z" clip-rule="evenodd" />
            <path fill-rule="evenodd" d="M7.646 4.646a.5.5 0 01.708 0l3 3a.5.5 0 01-.708.708L8 5.707 5.354 8.354a.5.5 0 11-.708-.708l3-3z" clip-rule="evenodd" />
          </svg></a>
      </div>
    </div>
  </div>
  <div class="info-husky-content-container">
    <!-- Husky safari -->
    <div class="row py-4">
      <div class="col-lg-4 col-md-6" id="safari">
        <div class="info-husky-content-image">
          <img class="img-fluid rounded-circle" alt="huskies in cage" src="images/visitourhuskysafari.jpg" />
        </div>
        <div class="info-husky-content">
          <h3>Visit our husky safari</h3>
          <p class="">
            Maecenas accumsan ornare sem, a placerat mi dictum et.
            Praesent eleifend mauris sed lacinia finibus. Pellentesque
            habitant morbi tristique senectus et netus et malesuada fames
            ac turpis egestas. Mauris mollis augue ut vehicula
            sollicitudin.
          </p>
          <div class="info-husky-pricing">
            <p>Opening hours:</p>
            <p>Prices:</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6" id="sledding">
        <div class="info-husky-content-image">
          <img class="img-fluid rounded-circle" alt="huskies in cage" src="images/huskysledding.jpg" />
        </div>
        <div class="info-husky-content">
          <h3>Husky Sledding</h3>
          <p class="">
            Suspendisse semper leo consequat lorem dictum tincidunt. Nam id
            ullamcorper velit, condimentum suscipit est. Duis auctor metus
            sit amet sapien accumsan tincidunt. Curabitur ut viverra ligula,
            nec gravida lorem. Integer dictum dui nulla, vitae egestas est
            tristique in.
          </p>
          <div class="info-husky-pricing">
            <p>Opening hours:</p>
            <p>Prices:</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4" id="hike">
        <div class="info-husky-content-image">
          <img class="img-fluid rounded-circle" alt="huskies in cage" src="images/hikewithahuskies.jpg" />
        </div>
        <div class="info-husky-content">
          <h3>Hike with huskies</h3>
          <p class="">
            Nunc faucibus vehicula ante, eu interdum urna consequat id. Ut
            congue auctor dolor sed viverra. Nullam pulvinar vestibulum orci
            vel iaculis. Nam porttitor mi dui, at ultricies magna tristique
            eu. Fusce congue sodales purus, quis gravida lorem facilisis
            vitae.
          </p>
          <div class="info-husky-pricing">
            <p>Opening hours:</p>
            <p>Prices:</p>
          </div>
        </div>
      </div>
    </div>

    <div class="row py-4">
      <div class="col-lg-4 col-md-6" id="play">
        <div class="info-husky-content-image">
          <img class="img-fluid rounded-circle" alt="huskies in cage" src="images/playwithhuskies.jpg" />
        </div>
        <div class="info-husky-content">
          <h3>Play with huskies</h3>
          <p class="">
            Maecenas accumsan ornare sem, a placerat mi dictum et. Praesent
            eleifend mauris sed lacinia finibus. Pellentesque habitant morbi
            tristique senectus et netus et malesuada fames ac turpis
            egestas. Mauris mollis augue ut vehicula sollicitudin.
          </p>
          <div class="info-husky-pricing">
            <p>Opening hours:</p>
            <p>Prices:</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6" id="walk">
        <div class="info-husky-content-image">
          <img class="img-fluid rounded-circle" alt="huskies in cage" src="images/walkwithhuskies.jpg" />
        </div>
        <div class="info-husky-content">
          <h3>Go walk with huskies</h3>
          <p class="">
            Suspendisse semper leo consequat lorem dictum tincidunt. Nam id
            ullamcorper velit, condimentum suscipit est. Duis auctor metus
            sit amet sapien accumsan tincidunt. Curabitur ut viverra ligula,
            nec gravida lorem. Integer dictum dui nulla, vitae egestas est
            tristique in.
          </p>
          <div class="info-husky-pricing">
            <p>Opening hours:</p>
            <p>Prices:</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4" id="other">
        <div class="info-husky-content-image">
          <img class="img-fluid rounded-circle" alt="huskies in cage" src="images/takeaphotowithhuskies.jpg" />
        </div>
        <div class="info-husky-content">
          <h3>Take a photo with Huskies</h3>
          <p class="">
            Nunc faucibus vehicula ante, eu interdum urna consequat id. Ut
            congue auctor dolor sed viverra. Nullam pulvinar vestibulum orci
            vel iaculis. Nam porttitor mi dui, at ultricies magna tristique
            eu. Fusce congue sodales purus, quis gravida lorem facilisis
            vitae.
          </p>
          <div class="info-husky-pricing">
            <p>Opening hours:</p>
            <p>Prices:</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<?php include './includes/footer.php'; ?>