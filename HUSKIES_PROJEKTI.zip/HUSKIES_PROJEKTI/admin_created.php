<?php if(!isset($_SESSION)) { session_start(); }

if (!isset($_SESSION["mail"]) || !isset($_SESSION["user"])) {
  include("session_expired.php");
} else {
  include("admin_created_successfully.php");
  unset($_SESSION["mail"],$_SESSION["user"]);
  session_destroy();
}
?>
