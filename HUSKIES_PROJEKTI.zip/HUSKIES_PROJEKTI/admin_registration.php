<?php  if(!isset($_SESSION)) { session_start(); }

$passreq = parse_ini_file("passwd.ini");

include("user_exists.php");

if (kayttaja_tyhja($_POST["user"])==true) {
  print "<p>Empty user field.Input username that you want to register.</p>";
} else if (tarkista_salasana($_POST["pass"],$_POST["verify"])==false) {
  print "<p>Empty password field or passwords don't match.</p>";
} else if (salasana_vaatimukset($_POST["pass"],$_POST["verify"],$passreq)==false) {
  print "<p>Password too short. The minimum length of password is "
  .$passreq["length"]." characters.</p>";
} else if (tarkista_sahkoposti($_POST["email"])==false) {
  print "<p>Empty or malformed email.</p>";
} else if (yhteys()!=false) {
  $yhteys=yhteys();
  $valmisteltu=valmistele_tiedot($yhteys);
  if ($valmisteltu!=false) {
    $tiedot=etsi_kayttaja($valmisteltu,$yhteys,$_POST["user"]);
    if ($tiedot!=false) {
      $haku=hae_tulokset($tiedot);
      if ($haku!=false) {
        print "<p>This username has been registered choose another username.</p>";
      } else {
        include("register_admin.php");
      }
    } else {
      mysqli_close($yhteys);
      print "2";
    }
  } else {
    mysqli_close($yhteys);
    print "3";
  }
} else {
  mysqli_close($yhteys);
  print "4";
}
?>
