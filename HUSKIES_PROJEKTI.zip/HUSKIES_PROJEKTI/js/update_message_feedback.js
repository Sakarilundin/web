 
 


 
$(document).ready(function(){

 
	$("#laheta").click(function(){
		$.post("savehunter.php",
		{
			newGuestbookMessage:$("#newGuestbookMessage").val(),
			pyssy:$("#pyssy").val()
		},
		function(data, status){
			$("#tulos").html(data);					
		});
	});
});
 
 


 