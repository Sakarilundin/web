<!DOCTYPE html>
<html lang="fi">
<head>
  <meta charset="utf-8"><title>Logged out</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <style>
    body {background:url(./images/husky.jpg) no-repeat center center fixed; background-size:cover;}
    div#ilmoitus{margin-left:auto; margin-right:auto; text-align:center;}
    div#ilmoitus h1 {color:#ffffff;}
  </style>
</head>
  <body>
    <div id="ilmoitus">
      <?php
        print "<h1>You have logged out of your session!</h1>";
        print "<a href='admin_login.html'><p>Login again</p></a>";
        print "<a href='home.php'><p>Back to homepage</p></a>";
      ?>
    </div>
  </body>
  </html>
