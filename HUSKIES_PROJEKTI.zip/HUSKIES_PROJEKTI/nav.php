<?php  

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
 ?>
<div class="text-center">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand nav-item-husky nav-husky-p" href="./index.php">Arctic Howl</a></li>
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item nav-item-husky nav-husky-p"><a class="nav-link" href="./home.php">Home</a></li>
                <li class="nav-item nav-item-husky nav-husky-p"><a class="nav-link" href="./info.php">Info</a></li>
                <li class="nav-item nav-item-husky nav-husky-p" ><a class="nav-link" href="./contactinfo.html">Contact</a></li>
                <li class="nav-item nav-item-husky nav-husky-p"><a class="nav-link" href="./guestbook.php">Guestbook</a></li>
                <li class="nav-item nav-item-husky nav-husky-p"><a class="nav-link" href="./admin_search.php">Admin</a></li>
				<?php
					if (isset($_SESSION["id"]) && isset($_SESSION["usr"]) && $_SESSION["loggedin"]==TRUE)  { 
						print "<li class='nav-item nav-item-husky nav-husky-p'><a class='nav-link' href='./users.php'>Users</a></li>";
						print "<li class='nav-item nav-item-husky nav-husky-p'><a class='nav-link' href='./exit_session.php'>Log out</a></li>";
					}
				?>
            </ul>
        </div>
    </nav>
    </div>