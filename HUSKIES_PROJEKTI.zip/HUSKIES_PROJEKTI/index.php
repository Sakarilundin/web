<?php  include './includes/header.php'; ?>

<?php  include './includes/nav.php'; ?>


    <div class="arctic-husky-container">
        <h1 class="main-husky-heading">ARCTIC HOWL</h1>
        <p class="husky-arctic-text">Welcome to expirience the world's northmost husky safari</p>
    </div>




<?php  include './includes/footer.php'; ?>

