<?php include './includes/header.php'; ?>
<?php include './includes/nav.php'; ?>
<?php include './includes/func.php'; ?>

 

<div>
     <script>

function run() {
     
	
	document.location.replace ("users.php?str14=" +document.getElementById("Pages").value);
	
}

</script>
     
     
<?php
 

 
# pagination 
if (isset($_GET['pageno'])) {
    
	 $pageno = test_input($_GET['pageno']);
} else {
    $pageno = 1;
}
 
 $no_of_records_per_page = 2;
 
  if (isset($_GET['str14'])) {
 
	$no_of_records_per_page = test_input($_GET['str14']);
 
 
 $_SESSION["pages"] = $no_of_records_per_page;
}
  if (isset( $_SESSION["pages"])) {
	 $no_of_records_per_page = $_SESSION["pages"];
 } 
 
  $no_of_records_per_page=2;
 
 
 $offset = ($pageno-1) * $no_of_records_per_page; 

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

 
$xml=simplexml_load_file("./config.xml");
//echo "<select id=\"Pages\" onchange=\"run()\"> ";
//echo "<option value=\"-\">$no_of_records_per_page</option>";
//echo "<option value=\"-\">2</option>";
//echo "<option value=\"10\">10</option>";
//echo "<option value=\"25\">25</option>";
//echo "<option value=\"50\">50</option>";
//echo "<option value=\"100\">100</option>";
//echo "<option value=\"250\">250</option>";     
//echo "<option value=\"500\">500</option>";     
//echo "</select>";
echo "<div>";
echo "<div class=\"arctic-husky-container\">";
$link = connect($xml->host,$xml->user,$xml->password ,$xml->database);
mysqli_set_charset($link,"utf8");
$total_pages_sql = "SELECT COUNT(*) FROM husky_test";
$result = mysqli_query($link,$total_pages_sql);
$total_rows = mysqli_fetch_array($result)[0];
$total_pages = ceil($total_rows / $no_of_records_per_page);
$ssql = "select * from husky_users LIMIT $offset, $no_of_records_per_page";
	//print ($ssql);
	if (isset($_GET['delete_husky_user'])) {
		//print("DELETE HUSKY USER");
		delete_husky_users($link, $_GET['delete_husky_user']);
	
    }
	
	
	if (isset($_GET['edit_husky_user'])) {
		print("EDIT USER");
		//delete_husky_users($link, $_GET['edit_husky_user']);
	
    }
 
	if ($result=mysqli_query($link,$ssql)){
		// Return the number of rows in result set
		$rowcount=mysqli_num_rows($result);
		#printf("Result set has %d rows.\n",$rowcount);
		
 
		echo "<center>";
		print_users($result);
		echo "</center>";
         
		// Free result set
		mysqli_free_result($result);
	}
	else {
		 //empty result set
	} 
  

	
 	 
  
	
?> 
 
 

 <CENTER>
 <TABLE>
    <TD><a href="?allr14=1&pageno=1"><img border="0" title="First Page" src="/images/first.png"></a></TD>
    <TD><?php if($pageno <= 1){   } ?>
        <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?allr14=1&pageno=".($pageno - 1); } ?>"><img border="0" title="Previous Page" src="/images/previous.png"></a></TD>
     
    <TD><?php if($pageno >= $total_pages){ } ?>
        <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?allr14=1&pageno=".($pageno + 1); } ?>"><img border="0" title="Next Page" src="/images/next.png"></a></TD>
    
    <TD><a href="?allr14=1&pageno=<?php echo $total_pages; ?>"><img border="0" title="Last Page" src="/images/last.png"></a></TD>
</TABLE>
</CENTER>

</div>

 
<?php  include './includes/footer.php'; ?>
 






 
